
import { Book, User, Idea, UserRole, BookStatus, IdeaStatus } from '../types';

// URL fornecida para integração com Google Sheets
const API_URL = 'https://script.google.com/macros/s/AKfycbyE4Sw6T-lHfUcm4zuCsRhau-hv8GMaJR_Plj8jRJHS3HuXYcR7UthwvBYY_YrwFCaWRA/exec';

const STORAGE_KEY = 'litte_escolhe_db';

const INITIAL_DATA = {
  books: [],
  users: [
    {
      user_id: 'u1',
      nome: 'Admin Litte',
      email: 'admin@litte.com',
      senha: 'admin',
      tipo: UserRole.ADMIN,
      ativo: true,
    }
  ],
  ideas: []
};

const getLocalDB = () => {
  const stored = localStorage.getItem(STORAGE_KEY);
  return stored ? JSON.parse(stored) : INITIAL_DATA;
};

const saveLocalDB = (data: any) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
};

export const mockDatabase = {
  getDB: async (): Promise<{books: Book[], users: User[], ideas: Idea[]}> => {
    try {
      if (!API_URL || API_URL.includes('SUA_URL_AQUI')) throw new Error("URL não configurada");
      
      const response = await fetch(`${API_URL}?action=getDB`, {
        method: 'GET',
        cache: 'no-store'
      });
      
      if (!response.ok) throw new Error("Erro na rede");
      
      const remoteData = await response.json();
      
      // Sanitização básica de dados booleanos vindos do Sheets
      if (remoteData.users) {
        remoteData.users = remoteData.users.map((u: any) => ({
          ...u,
          ativo: u.ativo === true || u.ativo === "TRUE" || u.ativo === "true"
        }));
      }
      
      if (remoteData.books) {
        remoteData.books = remoteData.books.map((b: any) => ({
          ...b,
          destaque: b.destaque === true || b.destaque === "TRUE" || b.destaque === "true"
        }));
      }

      saveLocalDB(remoteData);
      return remoteData;
    } catch (error) {
      console.warn("Usando LocalStorage devido a erro na API:", error);
      return getLocalDB();
    }
  },

  addBook: async (bookData: Omit<Book, 'book_id' | 'status'>): Promise<Book> => {
    const newBook: Book = {
      ...bookData,
      book_id: 'b' + Math.random().toString(36).substr(2, 5),
      status: BookStatus.ACTIVE
    };
    
    try {
      await fetch(API_URL, {
        method: 'POST',
        mode: 'no-cors',
        body: JSON.stringify({
          action: 'addRow',
          sheet: 'Livros',
          data: newBook
        })
      });
    } catch (e) {
      console.error("Erro ao enviar para o Sheets:", e);
    }

    const db = getLocalDB();
    db.books.unshift(newBook);
    saveLocalDB(db);
    return newBook;
  },

  updateBook: async (updatedBook: Book) => {
    try {
      await fetch(API_URL, {
        method: 'POST',
        mode: 'no-cors',
        body: JSON.stringify({
          action: 'updateRow',
          sheet: 'Livros',
          idColumn: 'book_id',
          idValue: updatedBook.book_id,
          data: updatedBook
        })
      });
    } catch (e) {}

    const db = getLocalDB();
    db.books = db.books.map((b: Book) => b.book_id === updatedBook.book_id ? updatedBook : b);
    saveLocalDB(db);
  },

  registerUser: async (userData: Pick<User, 'nome' | 'email' | 'senha'>): Promise<User> => {
    const newUser: User = {
      ...userData,
      user_id: 'u' + Math.random().toString(36).substr(2, 5),
      tipo: UserRole.USER,
      ativo: true
    };
    
    try {
      await fetch(API_URL, {
        method: 'POST',
        mode: 'no-cors',
        body: JSON.stringify({
          action: 'addRow',
          sheet: 'Usuários',
          data: newUser
        })
      });
    } catch (e) {}

    const db = getLocalDB();
    db.users.push(newUser);
    saveLocalDB(db);
    return newUser;
  },
  
  addIdea: async (idea: Omit<Idea, 'idea_id' | 'data_envio' | 'status'>) => {
    const newIdea: Idea = {
      ...idea,
      idea_id: 'i' + Math.random().toString(36).substr(2, 5),
      data_envio: new Date().toISOString(),
      status: IdeaStatus.NEW
    };
    
    try {
      await fetch(API_URL, {
        method: 'POST',
        mode: 'no-cors',
        body: JSON.stringify({
          action: 'addRow',
          sheet: 'Ideias',
          data: newIdea
        })
      });
    } catch (e) {}

    const db = getLocalDB();
    db.ideas.push(newIdea);
    saveLocalDB(db);
    return newIdea;
  },

  updateIdeaStatus: async (ideaId: string, status: IdeaStatus) => {
    try {
      await fetch(API_URL, {
        method: 'POST',
        mode: 'no-cors',
        body: JSON.stringify({
          action: 'updateRow',
          sheet: 'Ideias',
          idColumn: 'idea_id',
          idValue: ideaId,
          data: { status }
        })
      });
    } catch (e) {}

    const db = getLocalDB();
    db.ideas = db.ideas.map((i: Idea) => i.idea_id === ideaId ? { ...i, status } : i);
    saveLocalDB(db);
  },

  toggleUserStatus: async (userId: string, currentStatus: boolean) => {
    try {
      await fetch(API_URL, {
        method: 'POST',
        mode: 'no-cors',
        body: JSON.stringify({
          action: 'updateRow',
          sheet: 'Usuários',
          idColumn: 'user_id',
          idValue: userId,
          data: { ativo: !currentStatus }
        })
      });
    } catch (e) {}

    const db = getLocalDB();
    db.users = db.users.map((u: User) => u.user_id === userId ? { ...u, ativo: !currentStatus } : u);
    saveLocalDB(db);
  }
};
