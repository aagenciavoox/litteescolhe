
import React, { useState } from 'react';
import { Book, User } from '../types';
import { Send, X, Calendar, Tag, BookOpen, Quote, Sparkles } from 'lucide-react';

interface IdeaFormProps {
  book: Book;
  user: User;
  onSuccess: (ideaData: { text: string; type: string }) => void;
  onClose: () => void;
}

const IdeaForm: React.FC<IdeaFormProps> = ({ book, user, onSuccess, onClose }) => {
  const [ideaText, setIdeaText] = useState('');
  const [contentType, setContentType] = useState('Resenha');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ideaText.trim()) return;
    
    setLoading(true);
    setTimeout(() => {
      onSuccess({ text: ideaText, type: contentType });
      setLoading(false);
    }, 800);
  };

  const contentTypes = ['Resenha', 'Vídeo Curto', 'Newsletter', 'Podcast', 'Citação'];

  const formattedDate = new Date(book.data_lançamento).toLocaleDateString('pt-BR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="bg-brand-cream rounded-3xl md:rounded-[2.5rem] shadow-2xl overflow-hidden max-w-5xl w-full flex flex-col md:flex-row max-h-[95vh] border-brand-charcoal/5">
      {/* Coluna de Detalhes do Livro */}
      <div className="md:w-5/12 bg-white/50 p-6 sm:p-10 overflow-y-auto border-b md:border-b-0 md:border-r-2 border-brand-charcoal/5">
        <div className="flex justify-between items-start mb-6 md:hidden">
           <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-brand-rust/10 text-brand-rust rounded-full text-[9px] font-black uppercase tracking-widest border border-brand-rust/20">
              <BookOpen size={12} /> Detalhes da Obra
           </div>
           <button onClick={onClose} className="p-2 text-brand-charcoal/40 hover:text-brand-rust transition-colors">
            <X size={24} />
          </button>
        </div>

        <div className="flex flex-col gap-6 md:gap-8">
          <div className="flex flex-col sm:flex-row md:flex-col gap-6 items-center sm:items-start md:items-stretch">
            <div className="w-40 sm:w-32 md:w-full shrink-0 shadow-2xl rounded-2xl overflow-hidden border-4 border-white rotate-2 md:rotate-2 hover:rotate-0 transition-transform duration-500">
              <img src={book.capa_url} alt={book.título} className="w-full h-auto object-cover" />
            </div>
            <div className="text-center sm:text-left">
              <h2 className="text-2xl md:text-3xl font-serif font-bold text-brand-charcoal leading-tight mb-2">
                {book.título}
              </h2>
              <p className="text-lg md:text-xl text-brand-sage italic mb-4 font-medium">{book.autor}</p>
              
              <div className="flex flex-wrap justify-center sm:justify-start gap-2">
                {book.gêneros.map(g => (
                  <span key={g} className="text-[9px] md:text-[10px] bg-brand-forest text-white px-3 md:px-4 py-1.5 rounded-full font-black uppercase tracking-wider">
                    {g}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-6 md:space-y-8">
            <section>
              <h3 className="text-[10px] font-black text-brand-charcoal/30 uppercase tracking-[0.25em] mb-3 flex items-center gap-2">
                <BookOpen size={14} /> Sinopse Editorial
              </h3>
              <p className="text-brand-charcoal/80 text-sm leading-relaxed font-serif italic">
                {book.sinopse}
              </p>
            </section>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-1 gap-4 md:gap-6">
              <section className="p-4 bg-white/40 rounded-2xl border border-white">
                <h3 className="text-[10px] font-black text-brand-charcoal/30 uppercase tracking-[0.2em] mb-1 flex items-center gap-2">
                  <Calendar size={14} /> Lançamento
                </h3>
                <p className="text-brand-charcoal text-sm font-bold">{formattedDate}</p>
              </section>
              <section className="p-4 bg-white/40 rounded-2xl border border-white">
                <h3 className="text-[10px] font-black text-brand-charcoal/30 uppercase tracking-[0.2em] mb-2 flex items-center gap-2">
                  <Tag size={14} /> Categorias
                </h3>
                <div className="flex flex-wrap gap-2">
                  {book.tags.map(t => (
                    <span key={t} className="text-[9px] text-brand-rust font-black uppercase tracking-widest">#{t}</span>
                  ))}
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>

      {/* Coluna do Formulário de Ideias */}
      <div className="md:w-7/12 p-6 sm:p-10 md:p-14 overflow-y-auto relative flex flex-col bg-white">
        <button 
          onClick={onClose} 
          className="hidden md:block absolute top-8 right-8 text-brand-charcoal/20 hover:text-brand-rust p-2 rounded-full transition-all hover:rotate-90"
        >
          <X size={28} />
        </button>

        <div className="mb-8 md:mb-12 text-center md:text-left">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-brand-amber/10 text-brand-rust rounded-full text-[9px] md:text-[10px] font-black uppercase tracking-widest mb-4 md:mb-6 border border-brand-amber/20">
            <Sparkles size={14} /> Laboratório de Ideias
          </div>
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-brand-charcoal mb-4">Novo Ângulo?</h2>
          <p className="text-brand-sage text-base md:text-lg font-medium">Contribua com frescor criativo para nosso acervo.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8 md:space-y-10 flex-1">
          <div>
            <label className="block text-[11px] font-black text-brand-charcoal/40 uppercase tracking-[0.2em] mb-4">
              Formato de Conteúdo
            </label>
            <div className="flex flex-wrap gap-2 md:gap-3">
              {contentTypes.map(type => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setContentType(type)}
                  className={`px-4 md:px-6 py-2.5 md:py-3 rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-widest transition-all border-2 ${
                    contentType === type 
                      ? 'bg-brand-rust border-brand-rust text-white shadow-xl shadow-brand-rust/30' 
                      : 'bg-brand-cream border-transparent text-brand-forest hover:border-brand-sage/30'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-black text-brand-charcoal/40 uppercase tracking-[0.2em] mb-4 flex justify-between items-center">
              <span>Proposta Criativa</span>
              <span className={`text-[10px] ${ideaText.length > 500 ? 'text-brand-rust' : ''}`}>{ideaText.length}/1k</span>
            </label>
            <div className="relative group">
              <textarea
                required
                placeholder="Como você visualiza este conteúdo?"
                className="w-full h-40 md:h-56 p-6 bg-brand-cream border-2 border-transparent rounded-2xl md:rounded-[2rem] focus:bg-white focus:border-brand-sage transition-all outline-none resize-none text-brand-charcoal text-base font-serif italic"
                value={ideaText}
                onChange={(e) => setIdeaText(e.target.value)}
              />
              <Quote className="hidden sm:block absolute bottom-6 right-6 text-brand-forest/5 pointer-events-none group-focus-within:text-brand-forest/10 transition-colors" size={60} />
            </div>
          </div>

          <div className="mt-auto pt-6 flex flex-col gap-4">
            <button
              type="submit"
              disabled={loading || !ideaText.trim()}
              className="w-full py-5 md:py-6 bg-brand-forest text-white rounded-2xl md:rounded-[2rem] text-xs font-black uppercase tracking-[0.3em] flex items-center justify-center gap-4 hover:bg-brand-charcoal disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-xl md:shadow-2xl shadow-brand-forest/20 active:scale-95"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Send size={18} />
                  Publicar Curadoria
                </>
              )}
            </button>
            <p className="text-center text-[8px] md:text-[9px] text-brand-sage font-black uppercase tracking-[0.2em]">
              O item sairá da vitrine após a confirmação.
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default IdeaForm;
