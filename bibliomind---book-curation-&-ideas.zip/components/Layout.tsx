
import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { BookOpen, LogOut, LayoutDashboard, Lightbulb, Users, Menu, X, Sparkles } from 'lucide-react';

interface LayoutProps {
  user: User;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ user, onLogout, activeTab, setActiveTab, children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const isAdmin = user.tipo === UserRole.ADMIN;

  const NavItem = ({ id, label, icon: Icon }: { id: string; label: string; icon: any }) => (
    <button
      onClick={() => {
        setActiveTab(id);
        setIsMenuOpen(false);
      }}
      className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 whitespace-nowrap ${
        activeTab === id 
          ? 'bg-brand-sage text-white shadow-lg' 
          : 'text-white/60 md:text-white/60 hover:text-white hover:bg-white/5'
      }`}
    >
      <Icon size={20} />
      <span className="font-semibold text-sm tracking-wide">{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-brand-cream">
      {/* Mobile Header */}
      <header className="md:hidden bg-brand-charcoal text-white p-4 sticky top-0 z-50 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-brand-rust rounded-lg text-white">
            <Sparkles size={20} />
          </div>
          <h1 className="text-lg font-bold font-serif tracking-tight">Litte escolhe</h1>
        </div>
        <button 
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="p-2 hover:bg-white/10 rounded-lg transition-colors"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </header>

      {/* Mobile Dropdown Menu */}
      {isMenuOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-brand-charcoal pt-20 p-6 animate-in slide-in-from-top duration-300">
          <nav className="flex flex-col gap-4">
             {isAdmin ? (
              <>
                <NavItem id="dashboard" label="Visão Geral" icon={LayoutDashboard} />
                <NavItem id="books-admin" label="Acervo" icon={BookOpen} />
                <NavItem id="ideas-admin" label="Curadoria" icon={Lightbulb} />
                <NavItem id="users" label="Equipe" icon={Users} />
              </>
            ) : (
              <NavItem id="explore" label="Explorar Livros" icon={BookOpen} />
            )}
            <div className="mt-8 pt-8 border-t border-white/10">
               <button
                onClick={onLogout}
                className="flex items-center gap-2 text-brand-rust font-black uppercase tracking-widest text-xs"
              >
                <LogOut size={16} /> Encerrar Sessão
              </button>
            </div>
          </nav>
        </div>
      )}

      {/* Sidebar - Desktop Only */}
      <aside className="hidden md:flex w-72 bg-brand-charcoal text-white p-8 flex-col gap-10 shadow-2xl z-20 h-screen sticky top-0">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-brand-rust rounded-xl text-white shadow-lg shadow-brand-rust/20">
            <Sparkles size={26} />
          </div>
          <h1 className="text-2xl font-bold font-serif tracking-tight">Litte escolhe</h1>
        </div>

        <nav className="flex flex-col gap-2 flex-1">
          <p className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] mb-2 px-2">Menu Principal</p>
          {isAdmin ? (
            <>
              <NavItem id="dashboard" label="Visão Geral" icon={LayoutDashboard} />
              <NavItem id="books-admin" label="Acervo" icon={BookOpen} />
              <NavItem id="ideas-admin" label="Curadoria" icon={Lightbulb} />
              <NavItem id="users" label="Equipe" icon={Users} />
            </>
          ) : (
            <>
              <NavItem id="explore" label="Explorar Livros" icon={BookOpen} />
            </>
          )}
        </nav>

        <div className="pt-8 border-t border-white/10 flex flex-col gap-6">
          <div className="flex items-center gap-3 px-2">
            <div className="w-10 h-10 rounded-full bg-brand-forest flex items-center justify-center font-bold text-white border-2 border-white/10">
              {user.nome.charAt(0)}
            </div>
            <div className="flex flex-col">
              <p className="text-sm font-bold text-white leading-none mb-1">{user.nome}</p>
              <p className="text-[10px] text-brand-amber uppercase font-black tracking-widest">{user.tipo}</p>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 text-white/40 hover:text-brand-rust transition-colors text-xs font-bold uppercase tracking-widest"
          >
            <LogOut size={16} />
            Encerrar Sessão
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-12">
        <div className="max-w-6xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
