
import React from 'react';
import { Book, BookStatus } from '../types';
import { ChevronRight, Star, ToggleLeft, ToggleRight } from 'lucide-react';

interface BookCardProps {
  book: Book;
  onSelect?: (book: Book) => void;
  onToggleStatus?: (book: Book) => void;
  onToggleHighlight?: (book: Book) => void;
  isAdmin?: boolean;
}

const BookCard: React.FC<BookCardProps> = ({ 
  book, 
  onSelect, 
  onToggleStatus, 
  onToggleHighlight,
  isAdmin 
}) => {
  return (
    <div className={`group relative bg-white rounded-[2rem] overflow-hidden border-2 border-brand-forest/5 hover:border-brand-sage/30 hover:shadow-2xl transition-all duration-500 ${!isAdmin && 'cursor-pointer'}`}
         onClick={() => !isAdmin && onSelect?.(book)}>
      
      {/* Visual Header */}
      <div className="relative aspect-[3/4] overflow-hidden">
        <img 
          src={book.capa_url} 
          alt={book.título}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-brand-charcoal/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
        
        {book.destaque && (
          <div className="absolute top-4 left-4 bg-brand-amber text-brand-charcoal text-[10px] font-black px-3 py-1.5 rounded-full flex items-center gap-1.5 uppercase tracking-[0.15em] shadow-xl animate-pulse">
            <Star size={12} fill="currentColor" />
            Destaque
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-6">
        <div className="flex flex-wrap gap-2 mb-3">
          {book.gêneros.slice(0, 2).map(g => (
            <span key={g} className="text-[9px] bg-brand-cream text-brand-forest px-2.5 py-1 rounded-full font-black uppercase tracking-widest border border-brand-forest/10">
              {g}
            </span>
          ))}
        </div>
        <h3 className="text-xl font-serif font-bold text-brand-charcoal leading-tight mb-1 group-hover:text-brand-rust transition-colors">
          {book.título}
        </h3>
        <p className="text-sm text-brand-sage italic mb-5 font-medium">{book.autor}</p>

        {isAdmin ? (
          <div className="flex items-center justify-between pt-4 border-t border-brand-cream">
            <button 
              onClick={(e) => { e.stopPropagation(); onToggleStatus?.(book); }}
              className={`flex items-center gap-2 text-[10px] font-black uppercase tracking-widest ${book.status === BookStatus.ACTIVE ? 'text-brand-sage' : 'text-brand-rust'}`}
            >
              {book.status === BookStatus.ACTIVE ? <ToggleRight size={20} /> : <ToggleLeft size={20} />}
              {book.status === BookStatus.ACTIVE ? 'Ativo' : 'Pausado'}
            </button>
            <button 
              onClick={(e) => { e.stopPropagation(); onToggleHighlight?.(book); }}
              className={`p-2 rounded-full transition-all ${book.destaque ? 'text-brand-amber bg-brand-amber/10' : 'text-brand-cream hover:text-brand-amber'}`}
            >
              <Star size={20} fill={book.destaque ? "currentColor" : "none"} />
            </button>
          </div>
        ) : (
          <div className="flex items-center justify-between pt-4 border-t border-brand-cream text-brand-rust font-black text-[10px] uppercase tracking-[0.2em] group-hover:translate-x-1 transition-transform">
            Ver detalhes
            <ChevronRight size={16} />
          </div>
        )}
      </div>
    </div>
  );
};

export default BookCard;
