
import React from 'react';
import { Idea, Book, User, IdeaStatus } from '../types';
import { X, CheckCircle2, TrendingUp, Quote, Calendar, User as UserIcon, BookOpen } from 'lucide-react';

interface IdeaDetailModalProps {
  idea: Idea;
  book?: Book;
  user?: User;
  onClose: () => void;
  onUpdateStatus: (ideaId: string, status: IdeaStatus) => void;
}

const IdeaDetailModal: React.FC<IdeaDetailModalProps> = ({ 
  idea, 
  book, 
  user, 
  onClose, 
  onUpdateStatus 
}) => {
  const formattedDate = new Date(idea.data_envio).toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <div className="bg-brand-cream rounded-3xl md:rounded-[2.5rem] shadow-2xl overflow-hidden max-w-5xl w-full flex flex-col md:flex-row max-h-[90vh] border-brand-charcoal/5">
      {/* Coluna Lateral: Contexto do Livro */}
      <div className="md:w-1/3 bg-brand-charcoal p-8 flex flex-col gap-6 text-white">
        <div className="w-32 mx-auto md:w-full aspect-[3/4] rounded-2xl overflow-hidden shadow-2xl border-4 border-white/10 rotate-1">
          {book ? (
            <img src={book.capa_url} alt={book.título} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-white/5 flex items-center justify-center">
              <BookOpen size={40} className="opacity-20" />
            </div>
          )}
        </div>
        
        <div className="space-y-4">
          <div>
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 mb-1">Obra Referenciada</p>
            <h3 className="text-xl font-serif font-bold italic leading-tight">{book?.título || 'Título não encontrado'}</h3>
            <p className="text-sm text-brand-sage font-medium">{book?.autor}</p>
          </div>
          
          <div className="pt-4 border-t border-white/10">
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 mb-2">Curador Responsável</p>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-brand-sage flex items-center justify-center text-xs font-black">
                {user?.nome.charAt(0)}
              </div>
              <div>
                <p className="text-xs font-bold leading-none">{user?.nome}</p>
                <p className="text-[10px] text-white/40">{user?.email}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Coluna Principal: Conteúdo da Ideia */}
      <div className="md:w-2/3 p-8 md:p-14 bg-white overflow-y-auto relative flex flex-col">
        <button 
          onClick={onClose}
          className="absolute top-8 right-8 text-brand-charcoal/20 hover:text-brand-rust transition-all hover:rotate-90 p-2"
        >
          <X size={28} />
        </button>

        <div className="mb-10">
          <div className="flex flex-wrap items-center gap-3 mb-6">
            <span className="px-4 py-1.5 bg-brand-forest text-white rounded-full text-[10px] font-black uppercase tracking-widest">
              {idea.tipo_conteúdo}
            </span>
            <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${
              idea.status === IdeaStatus.NEW ? 'bg-brand-amber/20 text-brand-rust' :
              idea.status === IdeaStatus.APPROVED ? 'bg-brand-sage/20 text-brand-forest' :
              'bg-brand-forest/10 text-brand-sage'
            }`}>
              {idea.status}
            </span>
          </div>
          <h2 className="text-4xl font-serif font-bold text-brand-charcoal mb-2">Proposta Editorial</h2>
          <div className="flex items-center gap-2 text-brand-sage text-xs font-medium">
            <Calendar size={14} />
            Enviado em {formattedDate}
          </div>
        </div>

        <div className="flex-1 relative">
          <Quote className="absolute -top-4 -left-6 text-brand-cream size-20 -z-0" />
          <div className="relative z-10 text-brand-charcoal text-xl md:text-2xl font-serif italic leading-relaxed first-letter:text-5xl first-letter:font-bold first-letter:mr-3 first-letter:float-left first-letter:text-brand-rust">
            {idea.ideia_texto}
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-brand-cream flex flex-wrap gap-4">
          {idea.status !== IdeaStatus.APPROVED && (
            <button 
              onClick={() => onUpdateStatus(idea.idea_id, IdeaStatus.APPROVED)}
              className="flex-1 min-w-[200px] bg-brand-forest text-white py-4 px-6 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-3 hover:bg-brand-charcoal transition-all shadow-xl shadow-brand-forest/20 active:scale-95"
            >
              <CheckCircle2 size={18} />
              Aprovar Proposta
            </button>
          )}
          {idea.status !== IdeaStatus.REVIEWED && (
            <button 
              onClick={() => onUpdateStatus(idea.idea_id, IdeaStatus.REVIEWED)}
              className="flex-1 min-w-[200px] bg-brand-rust text-white py-4 px-6 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-3 hover:bg-brand-charcoal transition-all shadow-xl shadow-brand-rust/20 active:scale-95"
            >
              <TrendingUp size={18} />
              Mover para Revisão
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default IdeaDetailModal;
