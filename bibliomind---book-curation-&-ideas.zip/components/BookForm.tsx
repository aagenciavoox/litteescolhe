
import React, { useState } from 'react';
import { Book } from '../types';
import { X, Save, Image as ImageIcon, BookOpen, Hash, Star } from 'lucide-react';

interface BookFormProps {
  onSuccess: (bookData: Omit<Book, 'book_id' | 'status'>) => void;
  onClose: () => void;
}

const BookForm: React.FC<BookFormProps> = ({ onSuccess, onClose }) => {
  const [formData, setFormData] = useState({
    título: '',
    autor: '',
    capa_url: '',
    sinopse: '',
    gêneros: '',
    tags: '',
    data_lançamento: new Date().toISOString().split('T')[0],
    destaque: false,
  });

  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Simulação de delay para feedback de UX
    setTimeout(() => {
      onSuccess({
        ...formData,
        gêneros: formData.gêneros.split(',').map(g => g.trim()).filter(g => g),
        tags: formData.tags.split(',').map(t => t.trim()).filter(t => t),
      });
      setLoading(false);
    }, 800);
  };

  return (
    <div className="bg-brand-cream rounded-3xl md:rounded-[2.5rem] shadow-2xl overflow-hidden max-w-4xl w-full flex flex-col md:flex-row max-h-[95vh] border-brand-charcoal/5">
      {/* Visual Preview / Sidebar */}
      <div className="md:w-1/3 bg-brand-charcoal p-8 flex flex-col items-center justify-center gap-6 text-white text-center">
        <div className="w-full aspect-[3/4] bg-white/5 rounded-2xl border-2 border-dashed border-white/20 flex items-center justify-center overflow-hidden relative group">
          {formData.capa_url ? (
            <img 
              src={formData.capa_url} 
              alt="Preview" 
              className="w-full h-full object-cover"
              onError={(e) => (e.currentTarget.src = 'https://via.placeholder.com/400x600?text=URL+Invalida')}
            />
          ) : (
            <div className="flex flex-col items-center gap-2 opacity-40">
              <ImageIcon size={48} />
              <p className="text-[10px] font-black uppercase tracking-widest">Aguardando Capa</p>
            </div>
          )}
        </div>
        <div>
          <h3 className="text-xl font-serif font-bold italic mb-2">Editor de Catálogo</h3>
          <p className="text-xs text-white/40 font-medium">Preencha os dados à direita para registrar uma nova obra no sistema.</p>
        </div>
      </div>

      {/* Form Content */}
      <div className="md:w-2/3 p-8 md:p-12 bg-white overflow-y-auto relative">
        <button 
          onClick={onClose}
          className="absolute top-8 right-8 text-brand-charcoal/20 hover:text-brand-rust transition-all hover:rotate-90 p-2"
        >
          <X size={24} />
        </button>

        <div className="mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-brand-forest/10 text-brand-forest rounded-full text-[9px] font-black uppercase tracking-widest mb-4">
            <BookOpen size={12} /> Curadoria Interna
          </div>
          <h2 className="text-3xl font-serif font-bold text-brand-charcoal">Nova Obra Mestra</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="col-span-1">
              <label className="block text-[10px] font-black text-brand-charcoal/40 uppercase tracking-widest mb-2 px-1">Título da Obra</label>
              <input
                required
                type="text"
                placeholder="Ex: O Pequeno Príncipe"
                className="w-full p-4 bg-brand-cream/50 border-2 border-transparent rounded-2xl focus:bg-white focus:border-brand-sage transition-all outline-none text-sm font-medium"
                value={formData.título}
                onChange={e => setFormData({ ...formData, título: e.target.value })}
              />
            </div>
            <div className="col-span-1">
              <label className="block text-[10px] font-black text-brand-charcoal/40 uppercase tracking-widest mb-2 px-1">Autor / Escritor</label>
              <input
                required
                type="text"
                placeholder="Ex: Antoine de Saint-Exupéry"
                className="w-full p-4 bg-brand-cream/50 border-2 border-transparent rounded-2xl focus:bg-white focus:border-brand-sage transition-all outline-none text-sm font-medium"
                value={formData.autor}
                onChange={e => setFormData({ ...formData, autor: e.target.value })}
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-black text-brand-charcoal/40 uppercase tracking-widest mb-2 px-1">URL da Imagem de Capa</label>
            <input
              required
              type="url"
              placeholder="https://..."
              className="w-full p-4 bg-brand-cream/50 border-2 border-transparent rounded-2xl focus:bg-white focus:border-brand-sage transition-all outline-none text-sm font-medium"
              value={formData.capa_url}
              onChange={e => setFormData({ ...formData, capa_url: e.target.value })}
            />
          </div>

          <div>
            <label className="block text-[10px] font-black text-brand-charcoal/40 uppercase tracking-widest mb-2 px-1">Sinopse Editorial</label>
            <textarea
              required
              rows={3}
              placeholder="Uma breve descrição sobre a trama e temas..."
              className="w-full p-4 bg-brand-cream/50 border-2 border-transparent rounded-2xl focus:bg-white focus:border-brand-sage transition-all outline-none text-sm font-medium resize-none"
              value={formData.sinopse}
              onChange={e => setFormData({ ...formData, sinopse: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-[10px] font-black text-brand-charcoal/40 uppercase tracking-widest mb-2 px-1">Gêneros (vírgula)</label>
              <input
                required
                type="text"
                placeholder="Ficção, Clássico..."
                className="w-full p-4 bg-brand-cream/50 border-2 border-transparent rounded-2xl focus:bg-white focus:border-brand-sage transition-all outline-none text-sm font-medium"
                value={formData.gêneros}
                onChange={e => setFormData({ ...formData, gêneros: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-[10px] font-black text-brand-charcoal/40 uppercase tracking-widest mb-2 px-1">Data de Lançamento</label>
              <input
                required
                type="date"
                className="w-full p-4 bg-brand-cream/50 border-2 border-transparent rounded-2xl focus:bg-white focus:border-brand-sage transition-all outline-none text-sm font-medium"
                value={formData.data_lançamento}
                onChange={e => setFormData({ ...formData, data_lançamento: e.target.value })}
              />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-6 pt-4 border-t border-brand-charcoal/5">
            <label className="flex items-center gap-3 cursor-pointer group">
              <div className={`w-12 h-6 rounded-full transition-all relative ${formData.destaque ? 'bg-brand-amber' : 'bg-brand-charcoal/10'}`}>
                <input 
                  type="checkbox" 
                  className="hidden" 
                  checked={formData.destaque}
                  onChange={e => setFormData({ ...formData, destaque: e.target.checked })}
                />
                <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${formData.destaque ? 'left-7' : 'left-1'}`}></div>
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-brand-charcoal/60 group-hover:text-brand-charcoal">
                Destacar no Catálogo
              </span>
            </label>

            <button
              type="submit"
              disabled={loading}
              className="flex-1 w-full sm:w-auto bg-brand-charcoal text-white py-4 px-8 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-3 hover:bg-brand-rust transition-all shadow-xl shadow-brand-charcoal/10 active:scale-95 disabled:opacity-50"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Save size={16} />
                  Salvar Título
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BookForm;
